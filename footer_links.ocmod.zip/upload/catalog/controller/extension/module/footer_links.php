<?php
class ControllerExtensionModuleFooterLinks extends Controller {
    public function index() {
        // Intentionally left blank
    }
}
